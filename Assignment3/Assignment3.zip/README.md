# Daniel Crawford and Abhishek Thurlapati

# Requirements
The packages listed at the top of the R code are needed. Beside this, running the code is straightforward.

