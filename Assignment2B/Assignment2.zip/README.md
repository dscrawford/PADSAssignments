Authors:
Daniel Crawford
Abhishek Thurlapati

# Execution for Method 2B
Method 2B is created in google colab. Dataset is downloaded directly from the keras dataset. To run, simply click the link below and run each cell or run all the cells at once under the runtime tab. 

# Notes
Assignment2B_Iterations.pdf contains the table of model iterations, and the google colab code only has the latest/best iteration shown.

In the colab code, you can see the table of the images with their associated predictions.

# Google Colab Link
https://colab.research.google.com/drive/1hjI-t8vIPWCvmvTHFoNBVmuTIVJo7RWb?usp=sharing